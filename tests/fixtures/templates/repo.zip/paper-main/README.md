A placeholder project.
